gcc -lSOIL -framework GLUT -framework OpenGL -framework Cocoa fixedLighting.c -o fixedLighting ; ./fixedLighting

