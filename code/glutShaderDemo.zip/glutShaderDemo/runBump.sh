gcc -lSOIL -framework GLUT -framework OpenGL -framework Cocoa bump2.c -o bump2 ; ./bump2

