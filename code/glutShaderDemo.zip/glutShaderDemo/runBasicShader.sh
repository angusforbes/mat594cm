gcc -lSOIL -framework GLUT -framework OpenGL -framework Cocoa basicShader.c -o basicShader ; ./basicShader

