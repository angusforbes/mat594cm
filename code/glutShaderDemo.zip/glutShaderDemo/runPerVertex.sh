gcc -lSOIL -framework GLUT -framework OpenGL -framework Cocoa perVertex.c -o perVertex ; ./perVertex

