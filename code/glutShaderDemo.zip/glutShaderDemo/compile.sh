gcc -lSOIL -framework GLUT -framework OpenGL -framework Cocoa main.c -o main

