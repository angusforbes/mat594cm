gcc -lSOIL -framework GLUT -framework OpenGL -framework Cocoa multiTex.c -o multiTex ; ./multiTex

