gcc -lSOIL -framework GLUT -framework OpenGL -framework Cocoa perPixel.c -o perPixel ; ./perPixel

